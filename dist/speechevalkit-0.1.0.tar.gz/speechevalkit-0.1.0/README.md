# SpeechEvalKit

🎧 **SpeechEvalKit** is a clean, lightweight Python toolkit for evaluating speech generation, speech enhancement, and voice conversion systems.

It provides a simple API, batch directory evaluation, automatic audio loading/resampling/alignment, robust error handling, progress bars, and a colorful CLI.

---

## Features

- Simple Python API
- Command-line interface
- Batch directory evaluation
- Automatic filename matching
- Audio loading and resampling
- Mono conversion
- Trim/pad alignment
- Robust handling of corrupted or missing files
- Progress tracking with `tqdm`
- Rich terminal output
- JSON result logging

---

## Metrics

SpeechEvalKit supports:

- `pesq`
- `stoi`
- `si_sdr`
- `mcd`
- `cosine`

### Note on PESQ and STOI

True PESQ and STOI require specialized third-party implementations.

SpeechEvalKit remains runnable with only the core dependencies. If optional packages are installed:

```bash
pip install pesq pystoi
