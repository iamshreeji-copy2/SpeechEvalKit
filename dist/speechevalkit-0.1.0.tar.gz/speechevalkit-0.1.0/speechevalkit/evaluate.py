from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable

import numpy as np
from tqdm import tqdm

from speechevalkit.metrics.cosine import cosine_similarity
from speechevalkit.metrics.mcd import mcd
from speechevalkit.metrics.pesq import pesq_score
from speechevalkit.metrics.si_sdr import si_sdr
from speechevalkit.metrics.stoi import stoi_score
from speechevalkit.utils.alignment import align_pair
from speechevalkit.utils.audio import load_audio
from speechevalkit.utils.io import find_matched_audio_files, save_results_json

LOGGER = logging.getLogger(__name__)

MetricFn = Callable[[np.ndarray, np.ndarray, int], float]

SUPPORTED_METRICS: dict[str, MetricFn] = {
    "pesq": pesq_score,
    "stoi": stoi_score,
    "si_sdr": si_sdr,
    "mcd": mcd,
    "cosine": cosine_similarity,
}


def _setup_logging(verbose: bool = True) -> None:
    level = logging.INFO if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


def _normalize_metrics(metrics: list[str] | tuple[str, ...] | None) -> list[str]:
    if metrics is None:
        return ["pesq", "stoi", "mcd", "si_sdr", "cosine"]

    normalized = [m.strip().lower().replace("-", "_") for m in metrics]
    unknown = [m for m in normalized if m not in SUPPORTED_METRICS]
    if unknown:
        raise ValueError(
            f"Unsupported metric(s): {unknown}. "
            f"Supported metrics: {sorted(SUPPORTED_METRICS)}"
        )
    return normalized


def _nanmean(values: list[float]) -> float:
    arr = np.asarray(values, dtype=np.float64)
    if arr.size == 0 or np.all(np.isnan(arr)):
        return float("nan")
    return float(np.nanmean(arr))


def evaluate(
    ref_dir: str | Path,
    pred_dir: str | Path,
    metrics: list[str] | tuple[str, ...] | None = None,
    sample_rate: int = 16000,
    recursive: bool = False,
    show_progress: bool = True,
    save_json: str | Path | None = None,
    verbose: bool = True,
) -> dict[str, Any]:
    """
    Evaluate generated speech against reference speech.

    Parameters
    ----------
    ref_dir:
        Directory containing reference audio.
    pred_dir:
        Directory containing predicted/generated audio.
    metrics:
        Metrics to compute. Supported: pesq, stoi, mcd, si_sdr, cosine.
    sample_rate:
        Target sample rate used for loading and metric computation.
    recursive:
        If True, recursively searches subdirectories.
    show_progress:
        If True, displays tqdm progress bar.
    save_json:
        Optional path to save detailed results as JSON.
    verbose:
        If True, logs informational messages.

    Returns
    -------
    dict
        Dictionary with summary averages, per-file scores, skipped files,
        and metadata.
    """
    _setup_logging(verbose=verbose)

    ref_path = Path(ref_dir)
    pred_path = Path(pred_dir)

    if not ref_path.exists():
        raise FileNotFoundError(f"Reference directory does not exist: {ref_path}")
    if not pred_path.exists():
        raise FileNotFoundError(f"Prediction directory does not exist: {pred_path}")
    if not ref_path.is_dir():
        raise NotADirectoryError(f"Reference path is not a directory: {ref_path}")
    if not pred_path.is_dir():
        raise NotADirectoryError(f"Prediction path is not a directory: {pred_path}")

    selected_metrics = _normalize_metrics(metrics)
    matched_pairs, missing_predictions = find_matched_audio_files(
        ref_path,
        pred_path,
        recursive=recursive,
    )

    if not matched_pairs:
        raise RuntimeError(
            f"No matching audio files found between {ref_path} and {pred_path}"
        )

    LOGGER.info("Found %d matched files", len(matched_pairs))
    if missing_predictions:
        LOGGER.warning("Missing predictions for %d reference files", len(missing_predictions))

    per_file: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []

    iterator = tqdm(
        matched_pairs,
        desc="Evaluating",
        unit="file",
        disable=not show_progress,
    )

    for ref_file, pred_file in iterator:
        file_result: dict[str, Any] = {
            "file": ref_file.name,
            "ref_path": str(ref_file),
            "pred_path": str(pred_file),
            "metrics": {},
        }

        try:
            ref_audio, sr = load_audio(ref_file, target_sr=sample_rate, mono=True)
            pred_audio, _ = load_audio(pred_file, target_sr=sample_rate, mono=True)
            ref_audio, pred_audio = align_pair(ref_audio, pred_audio)
        except Exception as exc:
            LOGGER.warning("Skipping %s: audio loading failed: %s", ref_file.name, exc)
            skipped.append(
                {
                    "file": ref_file.name,
                    "reason": f"audio loading failed: {exc}",
                }
            )
            continue

        for metric_name in selected_metrics:
            metric_fn = SUPPORTED_METRICS[metric_name]
            try:
                score = metric_fn(ref_audio, pred_audio, sr)
                file_result["metrics"][metric_name] = float(score)
            except Exception as exc:
                LOGGER.warning(
                    "Metric %s failed for %s: %s",
                    metric_name,
                    ref_file.name,
                    exc,
                )
                file_result["metrics"][metric_name] = float("nan")

        per_file.append(file_result)

    summary = {}
    for metric_name in selected_metrics:
        values = [
            item["metrics"].get(metric_name, float("nan"))
            for item in per_file
        ]
        summary[metric_name] = _nanmean(values)

    result: dict[str, Any] = {
        "summary": summary,
        "per_file": per_file,
        "skipped": skipped,
        "missing_predictions": [str(path) for path in missing_predictions],
        "metadata": {
            "ref_dir": str(ref_path),
            "pred_dir": str(pred_path),
            "sample_rate": sample_rate,
            "metrics": selected_metrics,
            "num_matched": len(matched_pairs),
            "num_evaluated": len(per_file),
            "num_skipped": len(skipped),
            "recursive": recursive,
        },
    }

    if save_json is not None:
        save_results_json(result, save_json)
        LOGGER.info("Saved results to %s", save_json)

    return result
